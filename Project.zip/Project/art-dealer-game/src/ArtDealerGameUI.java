import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArtDealerGameUI extends JFrame {

    private JButton[] cardButtons = new JButton[52]; // Array for card buttons
    private JTextArea dealerFeedback;  // Text area for dealer's feedback
    private JComboBox<String> guessPatternBox; // Dropdown for selecting patterns
    private JLabel resultLabel;
    private JComboBox<String> stageSelector; // Dropdown for selecting game stage
    private int guessesRemaining = 3; // Guesses allowed
    private String currentPattern = ""; // To store dealer's pattern in multiplayer mode
    private String[] currentStagePatterns; // Current patterns for the selected stage
    private List<String> dealerPatterns = new ArrayList<>(); // Dealer's chosen patterns
    private boolean gameStarted = false; // To check if the game has started

    public ArtDealerGameUI() {
        setTitle("Art Dealer Game");
        setSize(600, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Initialize UI components
        JPanel stagePanel = createStageSelectionPanel(); // Panel for stage selection
        JPanel cardPanel = createCardPanel();            // Panel to select cards
        JPanel actionPanel = createActionPanel();        // Panel for guessing and feedback

        // Add the components to the window
        add(stagePanel, BorderLayout.NORTH);
        add(cardPanel, BorderLayout.CENTER);
        add(actionPanel, BorderLayout.SOUTH);
        
        disableCardButtons(); // Disable card buttons at the start
    }

    private JPanel createStageSelectionPanel() {
        JPanel stagePanel = new JPanel();
        stagePanel.add(new JLabel("Select Stage: "));

        String[] stages = {"K-2", "Grades 3-5", "Grades 6-8 (Multiplayer)"};
        stageSelector = new JComboBox<>(stages);
        stagePanel.add(stageSelector);

        JButton startButton = new JButton("Start Game");
        startButton.addActionListener(new StartButtonListener());
        stagePanel.add(startButton);

        return stagePanel;
    }

    private JPanel createCardPanel() {
        JPanel cardPanel = new JPanel(new GridLayout(4, 13)); // Grid layout for cards (4x13)

        Dimension buttonSize = new Dimension(50, 30); // Set preferred size for buttons

        // Initialize each button to represent a card from a deck
        for (int i = 0; i < 52; i++) {
            cardButtons[i] = new JButton(getCardLabel(i));
            cardButtons[i].setPreferredSize(buttonSize);  // Set the preferred size for each button
            cardButtons[i].addActionListener(new CardButtonListener());
            cardPanel.add(cardButtons[i]);
            cardButtons[i].setEnabled(false); // Disable cards initially
        }

        return cardPanel;
    }

    private JPanel createActionPanel() {
        JPanel actionPanel = new JPanel(new BorderLayout());

        // Feedback area
        dealerFeedback = new JTextArea(3, 20);
        dealerFeedback.setEditable(false);
        actionPanel.add(new JScrollPane(dealerFeedback), BorderLayout.CENTER);

        // Panel for guessing pattern
        JPanel guessPanel = new JPanel();
        guessPanel.add(new JLabel("Guess the pattern: "));

        guessPatternBox = new JComboBox<>();
        guessPanel.add(guessPatternBox);

        JButton guessButton = new JButton("Guess");
        guessButton.addActionListener(new GuessButtonListener());
        guessPanel.add(guessButton);

        resultLabel = new JLabel();
        guessPanel.add(resultLabel);

        actionPanel.add(guessPanel, BorderLayout.SOUTH);

        return actionPanel;
    }

    private String getCardLabel(int i) {
        String[] suits = {"Hearts", "Diamonds", "Clubs", "Spades"};
        String[] ranks = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"};
        return ranks[i % 13] + " of " + suits[i / 13];
    }

    // Event listener for card button clicks
    private class CardButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (!gameStarted) {
                JOptionPane.showMessageDialog(null, "Please start the game first!");
                return; // Return early if the game hasn't started
            }
            JButton clickedButton = (JButton) e.getSource();
            dealerFeedback.append("You selected: " + clickedButton.getText() + "\n");
            playAudio("../audio/card_click.wav"); // Play audio feedback on selection
            // Check if selected cards match the dealer's pattern
            if (currentStagePatterns != null) {
                checkPattern(clickedButton.getText());
            }
        }
    }

    // Event listener for guessing the pattern
    private class GuessButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String selectedPattern = (String) guessPatternBox.getSelectedItem();
            // Logic to check if the guessed pattern is correct
            if (selectedPattern != null && Arrays.asList(currentStagePatterns).contains(selectedPattern)) {
                resultLabel.setText("Correct! You win!");
                playAudio("../audio/win_sound.wav");
                showWinningAnimation();
            } else {
                guessesRemaining--;
                resultLabel.setText("Incorrect. Try again! " + guessesRemaining + " guesses left.");
                playAudio("../audio/incorrect_guess.wav");
                if (guessesRemaining == 0) {
                    JOptionPane.showMessageDialog(null, "Game Over! Restart to try again.");
                }
            }
        }
    }

    private class StartButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Reset game data
            resetGame();
    
            String selectedStage = (String) stageSelector.getSelectedItem();
            dealerFeedback.setText("Starting Stage: " + selectedStage + "\n");
            playAudio("../audio/start_stage.wav");
            gameStarted = true; // Set gameStarted to true after starting the game
            enableCardButtons(); // Enable card buttons after the game starts
    
            // Adjust the pattern complexity based on the stage
            if (selectedStage.equals("K-2")) {
                currentStagePatterns = new String[]{"All Red", "All Black", "All Hearts", "All Queens"};
                guessPatternBox.setModel(new DefaultComboBoxModel<>(currentStagePatterns));
            } else if (selectedStage.equals("Grades 3-5")) {
                currentStagePatterns = new String[]{"Single-Digit Primes", "Sum of 9", "Ace and a Jack"};
                guessPatternBox.setModel(new DefaultComboBoxModel<>(currentStagePatterns));
            } else if (selectedStage.equals("Grades 6-8 (Multiplayer)")) {
                // Multiplayer mode setup
                currentPattern = JOptionPane.showInputDialog("Player 1, choose a pattern from the list: Single-Digit Primes, Sum of 9, Ace and a Jack.");
                dealerPatterns.add(currentPattern);
                currentStagePatterns = new String[]{"Poker Pair", "Three of a Kind", "Flush", currentPattern}; // Example advanced patterns
                guessPatternBox.setModel(new DefaultComboBoxModel<>(currentStagePatterns));
            }
        }
    }
    
    // Method to reset game data
    private void resetGame() {
        dealerFeedback.setText("");         // Clear dealer feedback
        resultLabel.setText("");            // Clear result label
        guessesRemaining = 3;               // Reset guesses
    }    

    // Method to enable card buttons
    private void enableCardButtons() {
        for (JButton cardButton : cardButtons) {
            cardButton.setEnabled(true); // Enable all card buttons
        }
    }

    // Method to disable card buttons
    private void disableCardButtons() {
        for (JButton cardButton : cardButtons) {
            cardButton.setEnabled(false); // Disable all card buttons
        }
    }

    // Method for playing audio files
    private void playAudio(String audioFile) {
        try {
            Clip clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(new File(audioFile)));
            clip.start();
        } catch (Exception ex) {
            System.out.println("Error playing audio: " + ex.getMessage());
        }
    }

    // Placeholder method for showing winning animation
    private void showWinningAnimation() {
        JOptionPane.showMessageDialog(this, "Congratulations! You found the pattern!");
    }

    private void checkPattern(String selectedCard) {
        // Logic for checking if the selected card matches the dealer's pattern
        // You might need to implement the actual matching logic based on the patterns you define
        dealerFeedback.append("Checking card: " + selectedCard + "\n");
        // Example logic: Check if selected card matches a pattern
        // For now, we can just output the selected card
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ArtDealerGameUI game = new ArtDealerGameUI();
            game.setVisible(true);
        });
    }
}
