# Art Dealer Game

### Overview
The **Art Dealer Game** is an educational simulation designed to teach K-8 students about computation, computational thinking, and basic math concepts through a fun and interactive card game. The game progresses through three stages with increasing complexity, providing age-appropriate challenges for students in different grade levels.

### Game Concept
In this game, the player takes on the role of a **gallery owner** who attempts to deduce what types of "paintings" (represented by playing cards) the **art dealer** (the computer) is buying. The player lays out four cards from a deck each turn, and the art dealer responds by indicating which cards match the dealer’s buying pattern. The player wins by successfully determining the pattern and matching all four cards.

### Features
- **Grade-specific challenges**: 
  - **K-2**: Simple patterns such as "All Red," "All Black," or "All Hearts."
  - **3-5**: More advanced patterns, including sums of card values and prime numbers.
  - **6-8**: Complex patterns, including poker-style combinations and optional multiplayer mode.
- **Interactive gameplay**: Simple, clear visuals designed for young students with audio prompts.
- **Usability**: Robust design with a simple, kid-friendly interface that minimizes errors and allows for quick restarts.

---
## Technologies Used

- Java
- Java Swing
- Audio System (Java Sound API)
---

### How to Play

1. **Start the Game**:
   - Run the game, and the art dealer (computer) will secretly choose a pattern.
   
2. **Player Turn**:
   - The player selects 4 cards from the deck. The cards will be shown to the art dealer.
   
3. **Feedback**:
   - The art dealer responds by indicating if the cards match the hidden pattern.
   
4. **Guessing**:
   - After each round, the player can make a guess from a list of patterns (e.g., All Red, All Black, etc.). The player has 3 attempts to guess the pattern.

5. **Winning**:
   - If the player guesses correctly and matches all 4 cards, they win, and a celebration with flying balloons is shown!

6. **Game Over**:
   - If the player does not guess correctly after 3 attempts, the correct pattern is revealed, and the game ends.

### Game Stages

- **K-2**: Simple patterns such as all cards being red, black, hearts, or queens.
- **3-5**: Moderate difficulty patterns involving number calculations (e.g., sum to 9, single-digit primes).
- **6-8**: Complex patterns that introduce poker-like card combinations and an optional multiplayer mode where one player acts as the art dealer.

---

### Installation

1. **Clone the repository**:
   ```bash
   git clone https://github.com/your-username/art-dealer-game.git
2. **Navigate to the project directory**:
   ```bash
   Navigate to the project directory:
3. **Compile the code**:
- Ensure you have Java installed.
    ```bash
    javac ArtDealerGame.java Card.java
4. **Run the game**:
    ```bash
    java ArtDealerGame
5. **Audio Files**:
    Place your audio files in an audio directory relative to the project root. Ensure the following audio files are present:

    - card_click.wav
    - win_sound.wav
    - incorrect_guess.wav
    - start_stage.wav

#### Stage: K-2
- **Player selects cards**: Ace of Hearts, 3 of Hearts, 5 of Hearts, 7 of Hearts.
- **Art Dealer's Pattern**: All Hearts.
- **Player guesses**: All Hearts.
- **Output**:
  - **Dealer Feedback**: "You selected: Ace of Hearts, 3 of Hearts, 5 of Hearts, 7 of Hearts."
  - **Guess Result**: "Correct! You win!" (Celebration with flying balloons).

---

- **Player selects cards**: Ace of Diamonds, 3 of Diamonds, 5 of Clubs, 7 of Hearts.
- **Art Dealer's Pattern**: All Red.
- **Player guesses**: All Hearts.
- **Output**:
  - **Dealer Feedback**: "You selected: Ace of Diamonds, 3 of Diamonds, 5 of Clubs, 7 of Hearts."
  - **Guess Result**: "Incorrect. Try again! 2 guesses left."

---

- **Player selects cards**: 2 of Spades, 4 of Spades, 6 of Diamonds, 8 of Clubs.
- **Art Dealer's Pattern**: All Black.
- **Player guesses**: All Black.
- **Output**:
  - **Dealer Feedback**: "You selected: 2 of Spades, 4 of Spades, 6 of Diamonds, 8 of Clubs."
  - **Guess Result**: "Incorrect. Try again! 1 guess left."

---

- **Player selects cards**: 10 of Hearts, 3 of Hearts, King of Hearts, 5 of Diamonds.
- **Art Dealer's Pattern**: All Hearts.
- **Player guesses**: All Queens.
- **Output**:
  - **Dealer Feedback**: "You selected: 10 of Hearts, 3 of Hearts, King of Hearts, 5 of Diamonds."
  - **Guess Result**: "Incorrect. Game Over! The correct pattern was: All Hearts."

---

#### Stage: Grades 3-5
- **Player selects cards**: 2 of Hearts, 2 of Spades, 5 of Diamonds, Ace of Hearts.
- **Art Dealer's Pattern**: Sum of 9.
- **Player guesses**: Sum of 9.
- **Output**:
  - **Dealer Feedback**: "You selected: 2 of Hearts, 2 of Spades, 5 of Diamonds, Ace of Hearts."
  - **Guess Result**: "Correct! You win!" (Celebration with flying balloons).

---

- **Player selects cards**: 3 of Diamonds, 4 of Hearts, 1 of Clubs, 7 of Spades.
- **Art Dealer's Pattern**: Prime Numbers.
- **Player guesses**: Sum of 9.
- **Output**:
  - **Dealer Feedback**: "You selected: 3 of Diamonds, 4 of Hearts, 1 of Clubs, 7 of Spades."
  - **Guess Result**: "Incorrect. Try again! 2 guesses left."

---

- **Player selects cards**: 2 of Clubs, 2 of Hearts, 6 of Spades, 3 of Diamonds.
- **Art Dealer's Pattern**: Single-digit Primes.
- **Player guesses**: Single-digit Primes.
- **Output**:
  - **Dealer Feedback**: "You selected: 2 of Clubs, 2 of Hearts, 6 of Spades, 3 of Diamonds."
  - **Guess Result**: "Correct! You win!" (Celebration with flying balloons).

---

#### Stage: Grades 6-8 (Multiplayer)
- **Player 1 (Dealer) chooses pattern**: Two Pair.
- **Player 2 selects cards**: 2 of Hearts, 2 of Spades, 3 of Diamonds, 3 of Clubs.
- **Player 2 guesses**: Two Pair.
- **Output**:
  - **Dealer Feedback**: "You selected: 2 of Hearts, 2 of Spades, 3 of Diamonds, 3 of Clubs."
  - **Guess Result**: "Correct! You win!" (Celebration with flying balloons).

---

- **Player 1 (Dealer) chooses pattern**: All Red.
- **Player 2 selects cards**: 5 of Spades, 10 of Diamonds, Queen of Hearts, 4 of Clubs.
- **Player 2 guesses**: All Black.
- **Output**:
  - **Dealer Feedback**: "You selected: 5 of Spades, 10 of Diamonds, Queen of Hearts, 4 of Clubs."
  - **Guess Result**: "Incorrect. Try again! 2 guesses left."

---

- **Player 1 (Dealer) chooses pattern**: Full House.
- **Player 2 selects cards**: King of Hearts, King of Diamonds, Queen of Spades, Ace of Clubs.
- **Player 2 guesses**: Full House.
- **Output**:
  - **Dealer Feedback**: "You selected: King of Hearts, King of Diamonds, Queen of Spades, Ace of Clubs."
  - **Guess Result**: "Incorrect. Game Over! The correct pattern was: Full House."

### Files in the Repository

- **ArtDealerGameUI.java**:  The main Java file containing the game logic and user interface.
- **audio/**: Directory containing audio files used for game feedback. Ensure it includes:
    -  **card_click.wav**: Audio for card selection.
    - **win_sound.wav**: Audio for winning the game.
    - **incorrect_guess.wav**: Audio for incorrect guesses.
    - **start_stage.wav**: Audio for starting a new stage.
- **README.md**: This file, providing an overview of the project.
   